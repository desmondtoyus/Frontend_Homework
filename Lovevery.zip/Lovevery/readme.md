# Front-end Developer Homework - Desmond
![Homepage](./assets/home.png)

Due to the homework requirements, this project was built using HTML, CSS, and plain JavaScript. Most of my recent projects have been built with React.

# Description
## HTML

The main file (entry point) to this project is the index.html file in the root directory, I tried to structure it like a Single Page Application (SPA). For instance, on a successful Login, the content of the page is replaced with the success message, though it look like another page.

## CSS

The CSS file is located in the CSS folder in the project root (css/index.css). I used the CSS Grid and flexbox for the responsiveness of the project, at the moment CSS flex and grid are the most powerful layout systems in CSS.

## JS

The JavaScript file is located in the ‘js’ folder (js/index.js), this script includes functions that are used to control the menus, display HTML elements, and the HTTP POST request method to the Endpoint. The XMLHttpRequest method was used because it provides support for old browsers. However, since this project is not run from a server but loaded as a file, the request to the Endpoint would come from origin 'null' and it looks like the endpoint is not configured to accept null origins. As a result, the endpoint was returning the error: 

```node
	Access to XMLHttpRequest at 'http://secure-peak-05845.herokuapp.com/api/v1/sessions' from origin 'null' has been blocked by CORS policy: Response to preflight request doesn't pass access control check: No 'Access-Control-Allow-Origin' header is present on the requested resource. 
```

So, I used a proxy server between the client (browser) and the endpoint to bypass the error (see my comment in [_Comment_](./js/index.js) (./js/index.js) line 73).


## Testing

For the unit tests, since this is an HTML/CSS/JS project, I decided to go with the [_Qunit_](https://qunitjs.com/) test, because it provides the ability to run tests in the browser.  Most of my recent projects have been React projects where I use Jest and React Testing Library (RTL) for testing my components.  However, for this project, the QUnit test was good enough since the project is not rendered over a server, the ability to run tests in the browser makes it very useful (See image below).

![Link to Test](./assets/test-result.png)

Also, I did not mock the endpoint for the API test, in an ideal situation, I would mock API calls during testing. The test script is located in the [_Tests_](./__tests__/test.js) ‘__tests__/test.js’ folder from the root directory.


## Usage
**Start the App**
```node
Open the index.html [_Start the App_](./index.html) file in the root directory in the browser (I tested with Chrome & Safari).
```
## Running the Tests
![Link to Test](./assets/testlink.png)
```node
* First open the index.html file in the browser, in the navigation header, open 
    the ‘Shop’ (or ‘About Us’) dropdown (see image above),  
* Click the ‘Run Test’ from the dropdown menu lists.  
* The tests should start running automatically. 
* A total of 8 tests would run and the test results/progress would be displayed on top of the page.
* Please wait for the tests to run completely.
```