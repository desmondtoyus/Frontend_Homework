'use strict';

QUnit.module("Lovevery", function (hooks) {
    hooks.beforeEach(function () {
        // reseting the page's html element before each test
        resetPage()
    });
    QUnit.module('View', function () {
        QUnit.test('page should contain page title', function (assert) {
            const title = document.getElementsByTagName("title")[0].innerText;
            assert.equal(title, 'Lovevery');
        });

        QUnit.test('email input element should show placeholder email', function (assert) {
            const email = document.getElementById('email').placeholder;
            assert.equal(email, 'name@example.com');
        });

        QUnit.test('password input element should be empty', function (assert) {
            const password = document.getElementById('password').value;
            assert.equal(password, '');
        });
        QUnit.test('cart should show one item', function (assert) {
            const cart = document.getElementById('cart').innerText;
            assert.equal(cart, '1');
        });

    });


    QUnit.module('Login', function () {
        // In an ideal situation i will mock the the API response
        QUnit.test('should successfully login with correct credentials', function (assert) {
            assert.timeout(5000); // Timeout of 5 seconds
            const done = assert.async();
            document.getElementById('email').value = 'test@test.com';
            document.getElementById('password').value = 'password';
            document.getElementById('signIn-btn').click();

            setTimeout(() => {
                const welcome = document.getElementById('success-msg').innerText;
                assert.equal(welcome, 'Welcome Test User');
                done();
            }, 3000);

        });

        QUnit.test('should fail when email is wrong', function (assert) {
            assert.timeout(5000); // Timeout of 5 seconds
            const done = assert.async();
            document.getElementById('email').value = 'no_email@email.com';
            document.getElementById('password').value = 'password';
            document.getElementById('signIn-btn').click();
            setTimeout(() => {
                const failureMsg = document.getElementById('failure-msg').innerText;
                assert.equal(failureMsg, 'Email not found');
                done();
            }, 3000);

        });

        QUnit.test('should fail with bad password', function (assert) {
            assert.timeout(5000); // Timeout of 5 seconds
            const done = assert.async();
            document.getElementById('email').value = 'test@test.com';
            document.getElementById('password').value = 'wrong_password';
            document.getElementById('signIn-btn').click();
            setTimeout(() => {
                const failureMsg = document.getElementById('failure-msg').innerText;
                assert.equal(failureMsg, 'Error Not Authorized');
                done();
            }, 3000);

        });

        QUnit.test('should fail frontend validation if email or password is invalid', function (assert) {
            assert.timeout(5000); // Timeout of 5 seconds
            const done = assert.async();
            document.getElementById('email').value = 'desmond';
            document.getElementById('password').value = 'wrong_password';
            document.getElementById('signIn-btn').click();
            setTimeout(() => {
                const failureMsg = document.getElementById('failure-msg').innerText;
                assert.equal(failureMsg, 'Invalid Email address or password.');
                resetPage();
                done();
            }, 3000);

        });

    });
});