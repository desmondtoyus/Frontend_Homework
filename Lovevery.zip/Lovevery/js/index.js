'use strict';

// Menu toggling, adding and removing the open class
// when the elements are clicked.
function toggleShopDropdown() {
    document.getElementById('about').classList.remove('open');
    document.getElementById('shop').classList.toggle('open');
}

function toggleAboutDropdown() {
    document.getElementById('shop').classList.remove('open');
    document.getElementById('about').classList.toggle('open');
}


function toggleMobShopDropdown() {
    document.getElementById('mob-about').classList.remove('open');
    document.getElementById('mob-shop').classList.toggle('open');
}

function toggleMobAboutDropdown() {
    document.getElementById('mob-shop').classList.remove('open');
    document.getElementById('mob-about').classList.toggle('open');
}

function toggleMenu() {
    document.getElementById('menu').classList.toggle('menu-open');

}


// This function is called when login is successful
// Hides the form and displaces the Welcome message
function signInSuccess(msg) {
    document.getElementById('signIn-btn').style.display = 'none';
    document.getElementById('signIn-form').style.display = 'none';
    document.getElementById('new-account').style.display = 'none';
    document.getElementById('signIn-text').innerText = 'Sign Out';
    document.getElementById('signIn-text-mob').innerText = 'Sign Out';
    const success = document.getElementById('success-msg')
    success.style.display = 'block';
    success.innerText = msg;
}

// called when the login fails
// changes the input element border and return the error message;
function signInFailed(msg) {
    document.getElementById('email').style.border = '1px solid red';
    document.getElementById('password').style.border = '1px solid red';
    const failure = document.getElementById('failure-msg')
    failure.style.display = 'block';
    failure.innerText = msg;
}

//email validator
function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const loader = document.getElementById('loading');
    // checking that the email is valid and the password field is not empty
    if (!validateEmail(email) || !password.length) {
        signInFailed('Invalid Email address or password.');
        return
    }
    // show loading icon
    loader.style.display = 'inline-block';
    // using XMLHttpRequest because it supports old browsers
    const xhr = new XMLHttpRequest();
    // I'm using a Proxy to by-pass the cross-origin error, 
    // Since this file is not servered on any server, the origin will be 'null'.
    //Please allow origin 'null' on the Enpoint server to avoid the 
    // "No 'Access-Control-Allow-Origin' header is present on the requested resource" error.
    const url = "http://23.106.47.197:4006/http://secure-peak-05845.herokuapp.com/api/v1/sessions";
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            const json = JSON.parse(xhr.responseText);
            //Get the response message
            //Since the key would be different depending on success or failure
            //Hence, we use the value of the first key of the JSON returned;
            const msg = json[Object.keys(json)[0]];
            //hide loading icon
            loader.style.display = 'none';
            //success
            if (xhr.status === 200) {
                signInSuccess(msg);
            } else {
                signInFailed(msg);
            }
        }

    };
    const data = JSON.stringify({
        email,
        password
    });
    xhr.send(data);
}

//Logout function, reset the HTML elements;
function signOut(e) {
    e.preventDefault();
    resetPage();
}
// Reset HTML element to the original state
// used for logout and unit tests
function resetPage() {
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    document.getElementById('signIn-form').style.display = 'flex';
    document.getElementById('new-account').style.display = 'flex';
    document.getElementById('signIn-text').innerText = 'Sign In';
    document.getElementById('signIn-text-mob').innerText = 'Sign In';
    document.getElementById('signIn-btn').style.display = 'block';
    document.getElementById('loading').style.display = 'none';
    document.getElementById('email').style.border = '1px solid #9aa5af';
    document.getElementById('password').style.border = '1px solid #9aa5af';
    const success = document.getElementById('success-msg')
    success.style.display = 'none';
    success.innerText = '';
    const failure = document.getElementById('failure-msg');
    failure.style.display = 'none';
    failure.innerText = '';
}
// Create & Load the Qunit Test script
function loadScript(src) {
    let script = document.createElement('script');
    script.src = src;
    script.async = false;
    document.body.append(script);
}

// add the neccessary scripts to run Qunit test in the browser
function startTest(e) {
    e.preventDefault();
    resetPage();
    //Qunit script
    let src = 'https://code.jquery.com/qunit/qunit-2.9.2.js';
    //local test file
    let testPath = './__tests__/tests.js';
    loadScript(src);
    loadScript(testPath);
    // Add QUnit test container to the page
    // tests results and progress would be displayed here
    let testConstainer = document.getElementById('test-block');
    const qunit = document.createElement('div');
    const qunitFixture = document.createElement('div');
    qunit.setAttribute('id', 'qunit');
    qunitFixture.setAttribute('id', 'qunit-fixture');
    testConstainer.appendChild(qunit);
    testConstainer.appendChild(qunitFixture);
}